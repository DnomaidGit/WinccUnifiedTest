		let ArrayData = [];
		let ArrayColumn = [];
		let table;
		let selectedRow = null;
		//-----Filter define variables for input elements						
		let fieldEl = document.getElementById("filter-field");
		let typeEl = document.getElementById("filter-type");
		let valueEl = document.getElementById("filter-value");
		// Initialize the custom control (without a successful initialization, the CWC will remain empty. Make sure to include the webcc.min.js script!)
		// "result" is a boolean defining if the connection was successfull or not.
		function init(result) {
            if (result) {
                webccInterfaceInit();				
            } else {
                console.log('Connection NOK');
            }
        }
		WebCC.start(init, webccInterface.contract, EXTENSIONS, TIMEOUT);		
		function showDemoData() {
			// Get the table container element
			var tableContainer = document.getElementById("example-table");
		}
		function drawTable(columnStyleString, tableDataString) {
			try {
				var tabledata = (tableDataString && JSON.parse(tableDataString)) || [];
				var columnStyle = (columnStyleString && JSON.parse(columnStyleString)) || [];
			} catch(e) {
				console.error('Error parsing JSON:', e);
				return; 
			}
			//choose how the table should look like or behave. More information on http://tabulator.info/
			table = new Tabulator("#example-table", {
				height: 'calc(100% - 2px)', // set height of table to 100% minus 2 px, because the border of the table is 1px top and border
				data: tabledata, //load initial data into table
				layout: "fitColumns", //fit columns to width of table (optional)
				columns: columnStyle,
				selectable: true, // Enable selection				
				rowClick: function (e, row) { // Table configuration options
					// Deselect all rows
					if (selectedRow) {				
					table.deselectRow();
					}
					// Select the clicked row
					row.select();
					selectedRow = row;
				}  			
			});
		}
		function updateFilter(){
				var filterVal = fieldEl.options[fieldEl.selectedIndex].value;
				var typeVal = typeEl.options[typeEl.selectedIndex].value;
				var filterInput = valueEl.value;				
				if (filterVal === "ID") {
					filterInput = parseInt(filterInput, 10);
					if (isNaN(filterInput)) {
						filterInput = "";
					}
				}
				table.setFilter(filterVal, typeVal, filterInput);
		}
		function showRuntimeData() {						
			// Get the table container element
			var tableContainer = document.getElementById("example-table");
			// Attach a click event listener to the table container
			tableContainer.addEventListener("click", function () {
			//----- Get the selected row(s)
			var selectedRows = table.getSelectedRows();
			WebCC.Events.fire("SelectedRow",selectedRows[0]._row.data);						
			});
			//-----------------------------------------------------------------------------------
			//-----Filter			
			 updateFilter();							
			//Update filters on value change
			document.getElementById("filter-field").addEventListener("change", updateFilter);
			document.getElementById("filter-type").addEventListener("change", updateFilter);
			document.getElementById("filter-value").addEventListener("keyup", updateFilter);			
			//Clear filters on "Clear Filters" button click
			document.getElementById("filter-clear").addEventListener("click", function(){
				console.log('click: Clear filters button');
				fieldEl.value = "";
				typeEl.value = "=";
				valueEl.value = "";
				table.clearFilter();
			});			
			//-----------------------------------------------------------------------------------
			//-----Print button
			document.getElementById("print-table").addEventListener("click", function(){
				console.log('click: Print button');
				table.print(false, true);
			});
			//-----------------------------------------------------------------------------------
			//-----Download csv button
			document.getElementById("download-csv").addEventListener("click", function(){
				console.log('click: Download csv');
				table.download("csv", "data.csv");
			});
			//-----------------------------------------------------------------------------------
		}	