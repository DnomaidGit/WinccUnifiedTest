		let ArrayData = [];
		var columnStyle_ = null;
		var tableData_ = null;
		var table;
		var selectedRow = null;
		////////////////////////////////////////////
		// Initialize the custom control (without a successful initialization, the CWC will remain empty. Make sure to include the webcc.min.js script!)
		WebCC.start(
			// callback function; occurs when the connection is done or failed. 
			// "result" is a boolean defining if the connection was successfull or not.
			function (result) {
				if (result) {
					if (WebCC.isDesignMode) {
						showDemoData();
					}
					else {
						console.log('connected successfully');
						// Set current values when CWC shows up
						setProperty({ key: "TableDataString", value: WebCC.Properties.TableDataString });
						// Get the table container element
						var tableContainer = document.getElementById("example-table");
						// Attach a click event listener to the table container
						tableContainer.addEventListener("click", function () {
						// Get the selected row(s)
						var selectedRows = table.getSelectedRows();
						WebCC.Events.fire("SelectedRow",selectedRows[0]._row.data);						
						});
						// Subscribe for future value changes
						WebCC.onPropertyChanged.subscribe(setProperty);
					}
				}
				else {
					console.log('connection failed');
				}
			},
			// contract (same as manifest.json)
			{
				// Methods
				methods: {
					DrawTable: function(columnStyleString, tableDataString){
						columnStyle_ = JSON.parse(columnStyleString);
						tableData_ = JSON.parse(tableDataString);
						drawTable(false);
						columnStyle_ = null;
						tableData_ = null;
					}
				},
				// Events
				events: ["SelectedRow"],
				// Properties
				properties: {
					TableDataString: " ",
					ColumnStyleString: " "
				}
			},
			// placeholder to include additional Unified dependencies (not used in this example)
			[],
			// connection timeout
			10000
		);
		
		function showDemoData() {
			ArrayData = JSON.parse("[{\"ID\":\"1\",\"Name\":\"Test1\",\"Temperature\":\"1°C\",\"Time\":\"00_00_00 00_00_1999\"},{\"ID\":\"2\",\"Name\":\"Test2\",\"Temperature\":\"2°C\",\"Time\":\"00_00_01 00-00-1999\"}]");
			WebCC.Properties.ColumnStyleString = "[{\"title\":\"ID\", \"field\":\"ID\"},{\"title\":\"Name\", \"field\":\"Name\"},{\"title\":\"Temperature\", \"field\":\"Temperature\"},{\"title\":\"Time\", \"field\":\"Time\"}]";			
            WebCC.onPropertyChanged.subscribe(setProperty);
			drawTable(true);	
		}

		function setProperty(data) {
			switch (data.key) {
				case "TableDataString":
					if (data.value) {
						ArrayData = JSON.parse(data.value);
						drawTable(true);
					} else { //workaround to overwrite the static value again on page reload
						//WebCC.Properties.TableDataString = JSON.stringify(ArrayData);
					}
					break;
			}
		}

		function drawTable(triggeredByTag) {
			if (!triggeredByTag) {
				var tabledata = tableData_;
				var columnStyle = columnStyle_;
			}
			else
			{
				var tabledata = ArrayData;
				var columnStyle = JSON.parse(WebCC.Properties.ColumnStyleString);
			}
			//choose how the table should look like or behave. More information on http://tabulator.info/
			table = new Tabulator("#example-table", {
				height: 'calc(100% - 2px)', // set height of table to 100% minus 2 px, because the border of the table is 1px top and border
				data: tabledata, //load initial data into table
				layout: "fitColumns", //fit columns to width of table (optional)
				columns: columnStyle,
				selectable: true, // Enable selection				
				rowClick: function (e, row) { // Table configuration options
					// Deselect all rows
					if (selectedRow) {				
					table.deselectRow();
					}
					// Select the clicked row
					row.select();
					selectedRow = row;
				}  			
			});
		}